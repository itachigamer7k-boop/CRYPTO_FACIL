-- criar tabela wallet

CREATE TABLE wallet (

user TEXT PRIMARY KEY,

BRL REAL DEFAULT 0,

BTC REAL DEFAULT 0,

ETH REAL DEFAULT 0,

SOL REAL DEFAULT 0

);



-- criar usuário inicial

INSERT INTO wallet (

user,

BRL,

BTC,

ETH,

SOL

)

VALUES (

'jm',

10000,

0.12,

1.5,

25.5

);
