export default function handler(req, res) {
  const publicKey = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArlOQdEzMq+J5woLZ7uIP
95q5oGgqIvUnfkGeVvqG4YXJ035qfbAZiESJrzwFUx9KtO60HH/LbDOPcZiroLn3
GmjK6IAKT5wFKYV9XBFA/V7xbNC1HGN8P6H+H9KYOVrivLICbm0Vl65Vct/gftCw
EtXmg+6iX6gt0+hysbGp/v+48BAMw0HdfIJDRSl5Au5co6ORNo48s4TCFR4uJf1+
fvF3Kwsg+ryALNDXXPwJRQEdobMU6B2ULjPiWL2HxAxdlVUhwkkmOwbJ8mNruitU
Kg4CX4KIevmJIfMAwbRdooYwBaPxG1t/N7Xe6dzSlk4MqE12NYyDBmJRSRE95CXZ
9wIDAQAB
-----END PUBLIC KEY-----`;

  res.status(200).json({
    public_key: publicKey,
    created_at: Date.now()
  });
}