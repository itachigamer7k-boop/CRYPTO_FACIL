import axios from "axios";
import TAXAS from "./taxas.js";
import db from "./database.js";
import dotenv from "dotenv";

dotenv.config();

//////////////////////////////
// CONFIGURAÇÃO PAGBANK
//////////////////////////////

const PAGBANK_CONFIG = {
  token: process.env.PAGBANK_TOKEN,  // ✅ AGORA SEGURO
  baseUrl: process.env.PAGBANK_URL || "https://sandbox.api.pagseguro.com"
};

//////////////////////////////
// DEPOSITAR PIX (RECEBER)
//////////////////////////////

export async function depositarPix(req, res) {
  try {
    const valor = Number(req.body.valor);
    const taxa = TAXAS.PIX_DEPOSITO;
    const liquido = valor - taxa;

    // Gera ID único para referência [citation:1]
    const referencia = `dep_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Cria cobrança PIX via API de Pedidos [citation:4][citation:6]
    const response = await axios.post(
      `${PAGBANK_CONFIG.baseUrl}/orders`,
      {
        reference_id: referencia,
        customer: {
          name: req.body.nome || "Cliente",
          email: req.body.email || "cliente@email.com",
          tax_id: req.body.cpf || "12345678909" // CPF/CNPJ obrigatório [citation:2]
        },
        items: [
          {
            name: "Depósito via PIX",
            quantity: 1,
            unit_amount: Math.round(valor * 100) // PagBank usa centavos [citation:2]
          }
        ],
        qr_codes: [
          {
            amount: {
              value: Math.round(valor * 100)
            },
            expiration_date: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 min
          }
        ],

        notification_urls: [
          "https://seudominio.com/webhook/pagbank" // URL para notificações [citation:1]
        ]
      },
      {
        headers: {
          "Authorization": `Bearer ${PAGBANK_CONFIG.token}`, // ✅ USA O TOKEN DO .ENV
          "Content-Type": "application/json"
        }
      }
    );

    // Adiciona saldo líquido (você pode esperar o webhook para confirmar)
    db.run(
      "UPDATE users SET saldo_brl = saldo_brl + ? WHERE id = ?",
      [liquido, req.body.userId || 1]
    );

    res.json({
      pix: {
        qr_code: response.data.qr_codes[0].text, // Texto do QR Code
        qr_code_image: response.data.qr_codes[0].image, // Imagem base64
        copy_paste: response.data.qr_codes[0].text, // Código copia e cola
        expiration: response.data.qr_codes[0].expiration_date
      },
      taxa: taxa,
      liquido: liquido,
      referencia: referencia
    });

  } catch (err) {
    console.error("Erro no depósito PIX:", err.response?.data || err);
    res.status(500).json({ erro: "Erro ao gerar PIX" });
  }
}

//////////////////////////////
// SACAR PIX (ENVIAR)
//////////////////////////////

export async function sacarPix(req, res) {
  try {
    const token = await ensureAuth();
    const valor = Number(req.body.valor);
    const taxa = TAXAS.PIX_SAQUE;
    const liquido = valor - taxa;
    
    // Dados do destinatário [citation:1][citation:7]
    const chavePix = req.body.chavePix; // Email, CPF, CNPJ, telefone ou chave aleatória
    const tipoChave = detectarTipoChave(chavePix);
    const documento = req.body.cpf; // CPF/CNPJ obrigatório [citation:1]

    // Remove saldo total primeiro
    db.run(
      "UPDATE users SET saldo_brl = saldo_brl - ? WHERE id = ?",
      [valor, req.body.userId || 1]
    );

    // Envia PIX via Payout API [citation:1][citation:5]
    const referencia = `saque_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const payoutResponse = await axios.post(
      `${PAGBANK_CONFIG.baseUrl}/payouts`, // URL para Cross-border ou Gateway [citation:3]
      {
        reference: referencia,
        notification_url: "https://seudominio.com/webhook/pagbank",
        items: [
          {
            method: "PIX",
            country: "BR",
            destination: {
              key: chavePix
            },
            amount: {
              currency: "BRL",
              value: liquido // Valor em reais (não centavos para Payout)
            },
            payee: {
              document: {
                type: documento.length === 11 ? "CPF" : "CNPJ",
                value: documento.replace(/\D/g, "")
              },
              name: req.body.nome || "Cliente"
            },
            reference: referencia
          }
        ]
      },
      {
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      }
    );

    // Envia a taxa para sua conta separadamente
    if (taxa > 0) {
      await axios.post(
        `${PAGBANK_CONFIG.baseUrl}/payouts`,
        {
          reference: `taxa_${referencia}`,
          items: [
            {
              method: "PIX",
              country: "BR",
              destination: {
                key: "SEU_EMAIL_PIX" // Sua chave PIX para receber a taxa
              },
              amount: {
                currency: "BRL",
                value: taxa
              },
              payee: {
                document: {
                  type: "CPF",
                  value: "SEU_CPF"
                },
                name: "Seu Nome"
              },
              reference: `taxa_${referencia}`
            }
          ]
        },
        {
          headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json"
          }
        }
      );
    }

    res.json({
      status: payoutResponse.data.status, // PENDING, SUCCESS, FAILED [citation:1]
      cliente_recebe: liquido,
      taxa: taxa,
      referencia: referencia
    });

  } catch (err) {
    console.error("Erro no saque PIX:", err.response?.data || err);
    
    // Em caso de erro, reverte o saldo
    db.run(
      "UPDATE users SET saldo_brl = saldo_brl + ? WHERE id = ?",
      [req.body.valor, req.body.userId || 1]
    );
    
    res.status(500).json({ erro: "Erro ao enviar PIX" });
  }
}

// Webhook para receber notificações do PagBank [citation:1][citation:2]
export async function webhookPagBank(req, res) {
  try {
    const notificacao = req.body;
    
    // PagBank espera HTTP 204 para confirmar recebimento [citation:1]
    res.status(204).send();
    
    // Processa a notificação em background
    if (notificacao.notification_type === "payout") {
      // Notificação de saque
      const referencia = notificacao.reference;
      const status = notificacao.status; // SUCCESS, FAILED, REVERSED
      
      if (status === "FAILED" || status === "REVERSED") {
        // Devolve o saldo se falhou
        db.run(
          "UPDATE users SET saldo_brl = saldo_brl + ? WHERE id = (SELECT user_id FROM transacoes WHERE referencia = ?)",
          [valorRecuperado, referencia]
        );
      }
    }
    
  } catch (err) {
    console.error("Erro no webhook:", err);
  }
}

// Função auxiliar para detectar tipo de chave PIX [citation:7]
function detectarTipoChave(chave) {
  // Remove caracteres não numéricos
  const numeros = chave.replace(/\D/g, "");
  
  if (chave.includes("@")) return "email";
  if (chave.startsWith("+")) return "phone";
  if (numeros.length === 11) return "cpf";
  if (numeros.length === 14) return "cnpj";
  if (chave.includes("-")) return "random";
  return "unknown";
}