import db from "./database.js"

import TAXAS from "./taxas.js"



export function depositarPix(req,res){

const valor = req.body.valor

const taxa = TAXAS.PIX_DEPOSITO

const liquido = valor - taxa


db.run(

"UPDATE users SET saldo_brl = saldo_brl + ? WHERE id=1",

[liquido]

)


res.json({

depositado:liquido,

taxa:taxa

})

}



export function sacarPix(req,res){

const valor = req.body.valor

const taxa = TAXAS.PIX_SAQUE

const liquido = valor - taxa


db.run(

"UPDATE users SET saldo_brl = saldo_brl - ? WHERE id=1",

[valor]

)


res.json({

enviado:liquido,

taxa:taxa

})

}
