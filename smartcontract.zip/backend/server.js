import express from "express"
import cors from "cors"
import { depositarPix, sacarPix } from "./pix.js"
import { depositarCrypto, sacarCrypto } from "./crypto.js"
import axios from "axios"
import dotenv from "dotenv"
import db from "./database.js"
import fs from 'fs'
import crypto from 'crypto'

dotenv.config()

const app = express()
app.use(cors())
app.use(express.json())

// ============================================
// CONFIGURAÇÃO PAGBANK
// ============================================
const PAGBANK_TOKEN = process.env.PAGBANK_TOKEN
const PAGBANK_URL = process.env.PAGBANK_URL || "https://api.pagseguro.com" // PRODUÇÃO (já que você cadastrou a URL)

// ============================================
// ENDPOINTS ORIGINAIS (CRYPTO E PIX)
// ============================================
app.post("/pix/depositar", depositarPix)
app.post("/pix/sacar", sacarPix)
app.post("/crypto/depositar", depositarCrypto)
app.post("/crypto/sacar", sacarCrypto)

// ============================================
// ENDPOINTS PIX PAGBANK (EXISTENTES)
// ============================================

/**
 * Endpoint para GERAR PIX
 * POST /api/depositar-pix
 */
app.post("/api/depositar-pix", async (req, res) => {
    try {
        const { valor, email, nome, cpf } = req.body
        
        console.log("🔄 Gerando PIX:", { valor, email, nome, cpf })
        
        if (!valor || valor <= 0) {
            return res.status(400).json({ error: "Valor inválido" })
        }
        
        const referencia = `pix_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`
        
        const response = await axios.post(
            `${PAGBANK_URL}/orders`,
            {
                reference_id: referencia,
                customer: {
                    name: nome || "Cliente",
                    email: email || "cliente@email.com",
                    tax_id: cpf ? cpf.replace(/\D/g, "") : "12345678909"
                },
                items: [
                    {
                        name: "Depósito via PIX",
                        quantity: 1,
                        unit_amount: Math.round(parseFloat(valor) * 100)
                    }
                ],
                qr_codes: [
                    {
                        amount: {
                            value: Math.round(parseFloat(valor) * 100)
                        },
                        expiration_date: new Date(Date.now() + 30 * 60 * 1000).toISOString()
                    }
                ]
            },
            {
                headers: {
                    "Authorization": `Bearer ${PAGBANK_TOKEN}`,
                    "Content-Type": "application/json"
                }
            }
        )
        
        res.json({
            pix: {
                copy_paste: response.data.qr_codes[0].text,
                qr_code_image: response.data.qr_codes[0].text
            },
            taxa: parseFloat(valor) * 0.01,
            liquido: parseFloat(valor) * 0.99,
            referencia: referencia
        })
        
    } catch (error) {
        console.error("❌ Erro ao gerar PIX:", error.response?.data || error.message)
        res.status(500).json({ error: "Erro ao gerar PIX" })
    }
})

/**
 * Endpoint para VERIFICAR STATUS do PIX
 * GET /api/status-pix/:referencia
 */
app.get("/api/status-pix/:referencia", async (req, res) => {
    try {
        const { referencia } = req.params
        
        const response = await axios.get(
            `${PAGBANK_URL}/orders/${referencia}`,
            {
                headers: {
                    "Authorization": `Bearer ${PAGBANK_TOKEN}`
                }
            }
        )
        
        let status = "PENDING"
        if (response.data.status === "PAID") {
            status = "PAID"
        } else if (response.data.status === "EXPIRED" || response.data.status === "CANCELED") {
            status = "EXPIRED"
        }
        
        res.json({ status })
        
    } catch (error) {
        console.error("❌ Erro ao verificar status:", error.response?.data || error.message)
        
        if (error.response?.status === 404) {
            return res.json({ status: "EXPIRED" })
        }
        
        res.status(500).json({ error: "Erro ao verificar status" })
    }
})

/**
 * Endpoint de HEALTH CHECK
 * GET /health
 */
app.get("/health", (req, res) => {
    res.json({ status: "ok", timestamp: Date.now() })
})

// ============================================
// NOVOS ENDPOINTS - CONNECT CHALLENGE (PASSO FINAL)
// ============================================

/**
 * Endpoint para solicitar challenge ao PagBank
 * POST /api/solicitar-challenge
 */
app.post('/api/solicitar-challenge', async (req, res) => {
    try {
        console.log('🔄 Solicitando challenge ao PagBank...')
        
        // 1. Solicita o challenge à API do PagBank
        const response = await axios.post(
            `${PAGBANK_URL}/oauth2/token`,
            {
                grant_type: 'challenge',
                scope: 'certificate.create'
            },
            {
                headers: {
                    'Authorization': `Bearer ${PAGBANK_TOKEN}`,
                    'Content-Type': 'application/json'
                }
            }
        )
        
        const { challenge, access_token } = response.data
        console.log('✅ Challenge recebido, descriptografando...')
        
        // 2. Lê a chave privada (que você gerou e colocou na pasta)
        const privateKeyPem = fs.readFileSync('private-key.pem', 'utf8')
        
        // 3. Descriptografa o challenge com a chave privada
        const decryptedData = crypto.privateDecrypt(
            {
                key: privateKeyPem,
                padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                oaepHash: 'sha256'
            },
            Buffer.from(challenge, 'base64')
        )
        
        const challengeDecifrado = decryptedData.toString()
        console.log('🔓 Challenge descriptografado com sucesso!')
        
        // 4. Retorna o token (válido por 30 segundos)
        res.json({
            success: true,
            access_token: access_token,
            challenge_decifrado: challengeDecifrado,
            expires_in: 30,
            message: 'Token válido por 30 segundos para transferências PIX'
        })
        
    } catch (error) {
        console.error('❌ Erro no Connect Challenge:', error.response?.data || error.message)
        res.status(500).json({ 
            error: 'Erro ao processar challenge',
            detalhe: error.response?.data?.error_description || error.message
        })
    }
})

/**
 * Endpoint para transferir PIX (usando o token do challenge)
 * POST /api/transferir-pix
 */
app.post('/api/transferir-pix', async (req, res) => {
    try {
        const { access_token, valor, chave_pix_destino, nome_destino, cpf_destino } = req.body
        
        console.log('🔄 Realizando transferência PIX com token temporário...')
        
        // Aqui você implementará a chamada real para a API de transferência do PagBank
        // Por enquanto, apenas simulamos o sucesso
        
        res.json({
            success: true,
            message: 'Transferência PIX realizada com sucesso!',
            dados: {
                valor: valor,
                destino: chave_pix_destino,
                token_usado: access_token.substring(0, 10) + '...'
            }
        })
        
    } catch (error) {
        console.error('❌ Erro na transferência:', error)
        res.status(500).json({ error: 'Erro na transferência PIX' })
    }
})

// ============================================
// ENDPOINT DA CHAVE PÚBLICA (para referência)
// ============================================
app.get('/.well-known/pagbank-challenge', (req, res) => {
    const publicKey = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArlOQdEzMq+J5woLZ7uIP
95q5oGgqIvUnfkGeVvqG4YXJ035qfbAZiESJrzwFUx9KtO60HH/LbDOPcZiroLn3
GmjK6IAKT5wFKYV9XBFA/V7xbNC1HGN8P6H+H9KYOVrivLICbm0Vl65Vct/gftCw
EtXmg+6iX6gt0+hysbGp/v+48BAMw0HdfIJDRSl5Au5co6ORNo48s4TCFR4uJf1+
fvF3Kwsg+ryALNDXXPwJRQEdobMU6B2ULjPiWL2HxAxdlVUhwkkmOwbJ8mNruitU
Kg4CX4KIevmJIfMAwbRdooYwBaPxG1t/N7Xe6dzSlk4MqE12NYyDBmJRSRE95CXZ
9wIDAQAB
-----END PUBLIC KEY-----`

    res.json({
        public_key: publicKey,
        created_at: Date.now()
    })
})

// ============================================
// SALDO
// ============================================
app.get("/saldo", (req, res) => {
    db.get(
        "SELECT * FROM users WHERE id=1",
        (err, row) => {
            if (err) {
                return res.status(500).json({ error: err.message })
            }
            res.json(row)
        }
    )
})

// ============================================
// INICIAR SERVIDOR
// ============================================
app.listen(3000, () => {
    console.log("🚀 SERVIDOR RODANDO NA PORTA 3000")
    console.log("\n📌 ENDPOINTS DISPONÍVEIS:")
    console.log("\n--- CRYPTO (originais) ---")
    console.log("   POST /crypto/depositar")
    console.log("   POST /crypto/sacar")
    console.log("\n--- PIX (originais) ---")
    console.log("   POST /pix/depositar")
    console.log("   POST /pix/sacar")
    console.log("\n--- PAGBANK PIX ---")
    console.log("   POST /api/depositar-pix")
    console.log("   GET  /api/status-pix/:referencia")
    console.log("   GET  /health")
    console.log("\n--- CONNECT CHALLENGE (NOVO) ---")
    console.log("   POST /api/solicitar-challenge")
    console.log("   POST /api/transferir-pix")
    console.log("   GET  /.well-known/pagbank-challenge")
    console.log("\n--- SALDO ---")
    console.log("   GET  /saldo")
})