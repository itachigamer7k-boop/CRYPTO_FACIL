import { MercadoPagoConfig, Payment } from "mercadopago"

import TAXAS from "./taxas.js"

import db from "./database.js"



//////////////////////////////

// CONFIGURAÇÃO

//////////////////////////////

const client = new MercadoPagoConfig({

accessToken:"SEU_ACCESS_TOKEN"

})

const payment = new Payment(client)



//////////////////////////////

// DEPOSITAR PIX

//////////////////////////////

export async function depositarPix(req,res){

try{

const valor = Number(req.body.valor)

const taxa = TAXAS.PIX_DEPOSITO

const liquido = valor - taxa



// cria PIX

const pagamento = await payment.create({

body:{

transaction_amount: valor,

payment_method_id:"pix",

payer:{

email:"cliente@email.com"

}

}

})



// adiciona saldo liquido

db.run(

"UPDATE users SET saldo_brl = saldo_brl + ? WHERE id=1",

[liquido]

)



res.json({

pix:pagamento.point_of_interaction.transaction_data,

taxa:taxa,

liquido:liquido

})



}catch(err){

console.log(err)

res.status(500).json({erro:"erro pix"})

}

}



//////////////////////////////

// SACAR PIX

//////////////////////////////

export async function sacarPix(req,res){

try{

const valor = Number(req.body.valor)

const taxa = TAXAS.PIX_SAQUE

const liquido = valor - taxa



// remove saldo total

db.run(

"UPDATE users SET saldo_brl = saldo_brl - ? WHERE id=1",

[valor]

)



//////////////////////////////

// AQUI VOCÊ ENVIA PIX REAL

//////////////////////////////

// exemplo API banco

/*

await enviarPix({

valor:liquido,

chave:"PIX_CLIENTE"

})



// taxa vai pra sua conta

await enviarPix({

valor:taxa,

chave:"SEU_PIX"

})

*/




res.json({

status:"PIX enviado",

cliente_recebe:liquido,

taxa:taxa

})



}catch(err){

console.log(err)

res.status(500).json({erro:"erro saque pix"})

}

}
