import db from "./database.js"
import TAXAS from "./taxas.js"


export function depositarCrypto(req,res){

const valor = req.body.valor

const taxa = TAXAS.CRYPTO_DEPOSITO

const liquido = valor - taxa


db.run(

"UPDATE users SET saldo_usdt = saldo_usdt + ? WHERE id=1",

[liquido]

)

res.json({

depositado:liquido,

taxa:taxa

})

}



export function sacarCrypto(req,res){

const valor = req.body.valor

const taxa = TAXAS.CRYPTO_SAQUE

const liquido = valor - taxa


db.run(

"UPDATE users SET saldo_usdt = saldo_usdt - ? WHERE id=1",

[valor]

)


res.json({

sacado:liquido,

taxa:taxa

})

}
