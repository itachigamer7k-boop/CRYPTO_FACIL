import crypto from 'crypto';
import fs from 'fs';

// Gera par de chaves RSA de 2048 bits
crypto.generateKeyPair('rsa',
{
    modulusLength: 2048,
    publicKeyEncoding: {
      type: 'spki',
      format: 'pem'
    },
    privateKeyEncoding: {
      type: 'pkcs8',
      format: 'pem',
    }
  },
  (error, publicKey, privateKey) => {
    if (error) {
      console.error('Erro:', error);
      return;
    }
    
    // Salva as chaves em arquivos
    fs.writeFileSync('public-key.pem', publicKey);
    fs.writeFileSync('private-key.pem', privateKey);
    
    console.log('✅ Chaves geradas com sucesso!');
    console.log('\n🔑 Chave pública (use no endpoint):\n', publicKey);
    console.log('\n🔒 Chave privada (guarde com segurança):\n', privateKey);
  }
);