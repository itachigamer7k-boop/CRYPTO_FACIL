const TAXAS = {

PIX_DEPOSITO: 5,

PIX_SAQUE: 5,

CRYPTO_DEPOSITO: 1,

CRYPTO_SAQUE: 2

}

export default TAXAS
