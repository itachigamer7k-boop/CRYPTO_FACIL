import Web3 from "https://cdn.jsdelivr.net/npm/web3@4.3.0/+esm"

let web3
let contract
let account


///////////////////////////////////////
// CONFIG
///////////////////////////////////////


// COLE O CONTRATO
const contractAddress = "0xd9145CCE52D386f254917e481eB44e9943F39138"


// ABI FINAL

const abi = [

{
"name":"depositETH",
"type":"function",
"stateMutability":"payable",
"inputs":[]
},

{
"name":"withdrawETH",
"type":"function",
"inputs":[
{ "name":"amount","type":"uint256"}
]
},

{
"name":"depositUSDT",
"type":"function",
"inputs":[
{ "name":"amount","type":"uint256"}
]
},

{
"name":"withdrawUSDT",
"type":"function",
"inputs":[
{ "name":"amount","type":"uint256"}
]
},

{
"name":"depositWBTC",
"type":"function",
"inputs":[
{ "name":"amount","type":"uint256"}
]
},

{
"name":"withdrawWBTC",
"type":"function",
"inputs":[
{ "name":"amount","type":"uint256"}
]
}

]


///////////////////////////////////////
// CONECTAR
///////////////////////////////////////

export async function conectar(){


if(!window.ethereum){

alert("Instale MetaMask")

return

}


await window.ethereum.request({

method:"eth_requestAccounts"

})


web3 = new Web3(window.ethereum)

const accounts = await web3.eth.getAccounts()

account = accounts[0]


contract = new web3.eth.Contract(

abi,
contractAddress

)


console.log("Conectado:", account)

}



///////////////////////////////////////
// DEPOSITAR ETH
///////////////////////////////////////

export async function depositarETH(valor){


const wei = web3.utils.toWei(valor,"ether")


await contract.methods.depositETH().send({

from:account,

value:wei

})


alert("ETH depositado")

}



///////////////////////////////////////
// SACAR ETH
///////////////////////////////////////

export async function sacarETH(valor){

const wei = web3.utils.toWei(valor,"ether")


await contract.methods.withdrawETH(

wei

).send({

from:account

})


alert("ETH sacado")

}



///////////////////////////////////////
// USDT CONFIG
///////////////////////////////////////


// USDT ARBITRUM

const USDT =

"0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9"


const usdtAbi = [

{
"name":"approve",
"type":"function",
"inputs":[
{"name":"spender","type":"address"},
{"name":"amount","type":"uint256"}
]
}

]


///////////////////////////////////////
// DEPOSITAR USDT
///////////////////////////////////////

export async function depositarUSDT(valor){

const usdt = new web3.eth.Contract(

usdtAbi,
USDT

)


const amount = valor * 1e6


// autorizar

await usdt.methods.approve(

contractAddress,
amount

).send({

from:account

})


// depositar

await contract.methods.depositUSDT(

amount

).send({

from:account

})


alert("USDT depositado")

}



///////////////////////////////////////
// SACAR USDT
///////////////////////////////////////

export async function sacarUSDT(valor){

const amount = valor * 1e6


await contract.methods.withdrawUSDT(

amount

).send({

from:account

})


alert("USDT sacado")

}



///////////////////////////////////////
// BTC (WBTC)
///////////////////////////////////////


// WBTC ARBITRUM

const WBTC =

"0x2f2a2543b76a4166549f7aaab2e75bef0aefc5b0"


const btcAbi = usdtAbi



///////////////////////////////////////
// DEPOSITAR BTC
///////////////////////////////////////

export async function depositarBTC(valor){

const btc = new web3.eth.Contract(

btcAbi,
WBTC

)


const amount = valor * 1e8


await btc.methods.approve(

contractAddress,
amount

).send({

from:account

})


await contract.methods.depositWBTC(

amount

).send({

from:account

})


alert("BTC depositado")

}



///////////////////////////////////////
// SACAR BTC
///////////////////////////////////////

export async function sacarBTC(valor){

const amount = valor * 1e8


await contract.methods.withdrawWBTC(

amount

).send({

from:account

})


alert("BTC sacado")

}
