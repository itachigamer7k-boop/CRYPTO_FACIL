// script.js - Interatividade da página
document.addEventListener('DOMContentLoaded', function() {
    // Dados dinâmicos (simulando uma API)
    const userData = {
        name: 'JM Investimentos',
        balance: 12450.85,
        balanceChange: 5.24,
        assets: [
            { name: 'Bitcoin', symbol: 'BTC', amount: 0.12, value: 8230.10, icon: 'btc' },
            { name: 'Ethereum', symbol: 'ETH', amount: 1.50, value: 3420.75, icon: 'eth' }
        ]
    };

    // Atualizar informações do usuário
    updateUserInfo(userData);
    
    // Configurar navegação ativa
    setupNavigation();
    
    // Configurar botões de ação
    setupActionButtons();
    
    // Simular carregamento de mais ativos (para o botão "Ver todos")
    setupViewAllButton();
});

function updateUserInfo(data) {
    // Atualizar nome do usuário
    const userNameElement = document.querySelector('h1');
    if (userNameElement) {
        userNameElement.textContent = data.name;
    }
    
    // Atualizar saldo
    const balanceElement = document.querySelector('h2');
    if (balanceElement) {
        balanceElement.textContent = formatCurrency(data.balance);
    }
    
    // Atualizar percentual de mudança
    const changeElement = document.querySelector('.badge-success');
    if (changeElement) {
        changeElement.innerHTML = `+${data.balanceChange}% <i class="fa-solid fa-arrow-trend-up ml-1"></i>`;
    }
}

function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(value);
}

function setupNavigation() {
    const navIcons = document.querySelectorAll('.nav-icon');
    
    navIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            // Remover classe active de todos
            navIcons.forEach(i => i.classList.remove('active', 'blue'));
            
            // Adicionar classe active ao clicado
            this.classList.add('active');
            
            // Se for o ícone home, manter azul
            if (this.querySelector('.fa-house')) {
                this.classList.add('blue');
            }
            
            // Aqui você pode adicionar a lógica de navegação real
            console.log('Navegação clicada:', this.innerHTML);
        });
    });
}

function setupActionButtons() {
    const actionButtons = document.querySelectorAll('.action-button');
    
    actionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const action = this.nextElementSibling?.textContent || 'Ação';
            
            // Aqui você pode adicionar a lógica para cada ação
            switch(action) {
                case 'Enviar':
                    console.log('Abrir tela de envio');
                    break;
                case 'Receber':
                    console.log('Abrir tela de recebimento');
                    break;
                case 'Trocar':
                    console.log('Abrir tela de troca');
                    break;
                case 'Comprar':
                    console.log('Abrir tela de compra');
                    break;
                default:
                    console.log('Ação:', action);
            }
            
            // Feedback visual (opcional)
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 200);
        });
    });
}

function setupViewAllButton() {
    const viewAllBtn = document.querySelector('.view-all-btn');
    
    if (viewAllBtn) {
        viewAllBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Simular carregamento de mais ativos
            const assetsList = document.querySelector('.assets-list');
            
            if (assetsList) {
                // Aqui você pode implementar a lógica para mostrar mais ativos
                console.log('Carregar mais ativos...');
                
                // Exemplo de como adicionar um novo ativo
                const newAsset = createAssetCard(
                    'fa-brands fa-solana',
                    'Solana',
                    'SOL',
                    25.5,
                    1875.20,
                    'sol'
                );
                
                // Descomente a linha abaixo para testar a adição de um novo ativo
                // assetsList.appendChild(newAsset);
            }
        });
    }
}

function createAssetCard(iconClass, name, symbol, amount, value, iconType) {
    const card = document.createElement('div');
    card.className = 'asset-card';
    
    card.innerHTML = `
        <div class="asset-info">
            <div class="crypto-icon ${iconType}">
                <i class="${iconClass}"></i>
            </div>
            <div class="asset-details">
                <p>${name}</p>
                <p>${symbol}</p>
            </div>
        </div>
        <div class="asset-values">
            <p>${amount} ${symbol}</p>
            <p>${formatCurrency(value)}</p>
        </div>
    `;
    
    return card;
}

// Atualizar saldo em tempo real (simulação)
let currentBalance = 12450.85;

function simulateBalanceUpdate() {
    setInterval(() => {
        // Simular pequena variação no saldo
        const variation = (Math.random() * 100 - 50) / 100; // -0.5 a 0.5
        currentBalance += variation;
        
        const balanceElement = document.querySelector('h2');
        if (balanceElement) {
            balanceElement.textContent = formatCurrency(currentBalance);
        }
        
        // Atualizar percentual (simplificado)
        const changeElement = document.querySelector('.badge-success');
        if (changeElement) {
            const randomChange = (Math.random() * 10 - 5).toFixed(2);
            const symbol = randomChange >= 0 ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down';
            const color = randomChange >= 0 ? 'text-green-400' : 'text-red-400';
            
            changeElement.innerHTML = `${randomChange}% <i class="fa-solid ${symbol} ml-1"></i>`;
            changeElement.className = `badge ${randomChange >= 0 ? 'badge-success' : 'bg-red-900/30 text-red-400'}`;
        }
    }, 30000); // Atualizar a cada 30 segundos
}

// Descomente a linha abaixo para ativar a simulação de atualização
// simulateBalanceUpdate();

// Adicionar suporte para tema escuro/claro (opcional)
function toggleTheme() {
    // Esta função pode ser expandida para suportar troca de tema
    console.log('Toggle theme functionality can be added here');
}

// Função para controlar visibilidade do saldo
function setupSaldoVisibility() {
    const toggleButton = document.getElementById('toggleSaldo');
    const saldoElement = document.getElementById('saldoValor');
    const eyeIcon = document.getElementById('eyeIcon');
    
    if (!toggleButton || !saldoElement || !eyeIcon) return;
    
    // Estado inicial (saldo visível)
    let saldoVisivel = true;
    
    // Recuperar preferência salva (se existir)
    const preferenciaSalva = localStorage.getItem('saldoVisivel');
    if (preferenciaSalva !== null) {
        saldoVisivel = preferenciaSalva === 'true';
        atualizarVisibilidadeSaldo(saldoVisivel);
    }
    
    toggleButton.addEventListener('click', function() {
        saldoVisivel = !saldoVisivel;
        atualizarVisibilidadeSaldo(saldoVisivel);
        
        // Salvar preferência
        localStorage.setItem('saldoVisivel', saldoVisivel);
    });
}

function atualizarVisibilidadeSaldo(visivel) {
    const saldoElement = document.getElementById('saldoValor');
    const eyeIcon = document.getElementById('eyeIcon');
    
    if (visivel) {
        // Mostrar saldo
        saldoElement.classList.remove('saldo-hidden');
        eyeIcon.className = 'fa-regular fa-eye';
        eyeIcon.parentElement.setAttribute('title', 'Esconder saldo');
    } else {
        // Esconder saldo
        saldoElement.classList.add('saldo-hidden');
        eyeIcon.className = 'fa-regular fa-eye-slash';
        eyeIcon.parentElement.setAttribute('title', 'Mostrar saldo');
    }
}

// Chamar a função quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    // ... seu código existente ...
    setupSaldoVisibility();
});


////////////////////////////////////////////////////
//
// INTEGRAÇÃO BACKEND - DEPOSITO PIX REAL
//
////////////////////////////////////////////////////


const API = "http://localhost:3000"


async function criarDepositoPIX() {

try{

const valorInput = document.getElementById("valorDeposito")

if(!valorInput){

console.log("campo valorDeposito não existe nesta página")

return

}

const valor = parseFloat(valorInput.value)


if(!valor || valor <= 0){

alert("Digite um valor válido")

return

}


const res = await fetch(API + "/depositar", {

method:"POST",

headers:{

"Content-Type":"application/json"

},

body: JSON.stringify({

valor: valor

})

})


const data = await res.json()


// redireciona para pagamento PIX

window.location.href = data.link


}catch(erro){

console.error(erro)

alert("Erro ao criar depósito")

}

}



////////////////////////////////////////////////////
//
// CONECTAR BOTÃO CONTINUAR
//
////////////////////////////////////////////////////


document.addEventListener("DOMContentLoaded", ()=>{


const btn = document.getElementById("btnContinuar")


if(btn){

btn.addEventListener("click", ()=>{


const metodo = document.querySelector('input[name="metodo"]:checked')


if(metodo && metodo.value === "pix"){

criarDepositoPIX()

}


})


}


})

