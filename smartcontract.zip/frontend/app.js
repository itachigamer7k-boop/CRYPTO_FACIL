async function sacarCrypto(){

await fetch("http://localhost:3000/sacar-crypto",{

method:"POST",

headers:{

"Content-Type":"application/json"
},

body: JSON.stringify({

moeda:"BTC",

amount:0.01,

enderecoCliente:"ENDERECO_CLIENTE",

userId:1

})

});

}
