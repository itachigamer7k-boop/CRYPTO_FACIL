// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

interface IERC20 {

function transferFrom(address from,address to,uint amount) external returns(bool);

function transfer(address to,uint amount) external returns(bool);

}


contract Bank {


address public owner;


uint public taxaDeposito = 1 ether;

uint public taxaSaque = 2 ether;


IERC20 public usdt;


mapping(address => uint) public saldo;



constructor(address _usdt){

owner = msg.sender;

usdt = IERC20(_usdt);

}



function deposit(uint amount) public {

require(amount > taxaDeposito);

usdt.transferFrom(msg.sender,address(this),amount);


uint liquido = amount - taxaDeposito;


saldo[msg.sender] += liquido;


usdt.transfer(owner,taxaDeposito);

}



function withdraw(uint amount) public {

require(saldo[msg.sender] >= amount);


saldo[msg.sender] -= amount;


uint taxa = taxaSaque;

uint liquido = amount - taxa;


usdt.transfer(msg.sender,liquido);

usdt.transfer(owner,taxa);

}


}
